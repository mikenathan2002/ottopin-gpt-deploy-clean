# OttoPin Streamlit or FastAPI app entry point
